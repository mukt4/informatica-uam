package Excepciones;

/**
 * Clase publica CruceNuloException que hereda de la clase Exception
 * @author Guillermo Hoyo Bravo y Tomas Higuera Viso
 * @version 1.0
 */
public class CruceNuloException extends Exception{
    /**
     * Constructor de la excepcion CruceNuloException
     */
    public CruceNuloException(){
    }
}
