package p2.autoescuela.clases;
/**
* Implementacion de la clase de Profesor
*
* @author Tomas Higuera Viso tomas.higuera@estudiante.uam.es y Guillermo Hoyo Bravo guillermo.hoyo@estudiabte.uam.es
*
*/
public class Profesor {
	private int id;
	private String nombre;
	private String apellido;
	private Fecha f_ini;
	private Fecha f_fin;
	
	/**
	 * Constructor del objeto Profesor
	 */
	public Profesor() {
		
	}
	
	/**
	 * Metodo getter del nombre del profesor
	 * @return String devuelve el nombre del profesor
	 */
	public String getNombre() {
		return nombre;
	}
	
	/**
	 * Metodo Setter del nombre del profesor
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	/**
	 * Metodo getter del apellido del profesor
	 * @return String devuelve el apellido del profesor
	 */
	public String getApellido() {
		return apellido;
	}
	
	/**
	 * Metodo Setter del apellido del profesor
	 */
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	
	/**
	 * Metodo getter de la decha de inicio del profesor
	 * @return String devuelve la fecha de inicio del profesor
	 */
	public Fecha getF_ini() {
		return f_ini;
	}
	
	/**
	 * Metodo Setter de la fecha de inicio del profesor
	 */
	public void setF_ini(Fecha f_ini) {
		this.f_ini = f_ini;
	}
	
	/**
	 * Metodo getter de la fecha fin del profesor
	 * @return String devuelve la fecha fin del profesor
	 */
	public Fecha getF_fin() {
		return f_fin;
	}
	
	/**
	 * Metodo Setter de la fecha fin del profesor
	 */
	public void setF_fin(Fecha f_fin) {
		this.f_fin = f_fin;
	}

	/**
	 * Metodo getter del id del profesor
	 * @return String devuelve el id del profesor
	 */
	public int getId() {
		return id;
	}

	/**
	 * Metodo Setter del id del profesor
	 */
	public void setId(int id) {
		this.id = id;
	}
	
}
