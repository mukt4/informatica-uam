package p2.autoescuela.clases;
/**
* Implementacion de la clase de alumno 
*
* @author Tomas Higuera Viso tomas.higuera@estudiante.uam.es y Guillermo Hoyo Bravo guillermo.hoyo@estudiabte.uam.es
*
*/


public class Alumno {
	private String dni;
	private String nombre;
	private String apellido;
	private Fecha fecha;
	private String carnet;
	
	/**
	 * Constructor del objeto Alumno
	 * @param dni Su dni
	 * @param nombre Su nombre
	 * @param apellido Su apellido
	 * @param anyo El anyo para la fecha
	 * @param mes El mes para la fecha
	 * @param dia El dia para la fecha
	 * @param carnet El carnet al que se presenta
	 */
	public Alumno(String dni, String nombre, String apellido, int anyo, int mes, int dia, String carnet) {
		this.dni = dni;
		this.nombre = nombre;
		this.apellido = apellido;
		this.fecha = new Fecha(dia, mes, anyo);
		this.carnet = carnet;
	}
	
	/**
	 * Metodo que devuelve la fecha
	 * @return Fecha Devuelve tipo fecha
	 */
	public Fecha getFechaMatr() {
		return fecha;
	}
	
	/**
	 * Metodo que devuelve la info de alumno
	 * @return String Devuelve un string que contiene la info de alumno
	 */
	public String toString() {
		String a;
		a = "Nombre: " + nombre + "\nApellido: " + apellido + "\nDNI: " + dni + "\nFecha Matricula: " + fecha + "\nTipo Carnet: " + carnet;
		return a;
	}

}
