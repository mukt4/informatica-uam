package p2.autoescuela.clases;
/**
* Implementacion de la clase de Fecha
*
* @author Tomas Higuera Viso tomas.higuera@estudiante.uam.es y Guillermo Hoyo Bravo guillermo.hoyo@estudiabte.uam.es
*
*/
public class Fecha {
	public int anyo;
	public int mes;
	public int dia;
	
	/**
	 * Constructor del objeto Fecha
	 */
	public Fecha(int dia, int mes, int anyo) {
		this.dia=dia;
		this.mes=mes;
		this.anyo=anyo;
	}
	
	/**
	 * Constructor que comprueba si una fecha es valida
	 * @return boolean
	 */
	public boolean isFechaValida() {
		if(anyo > 0) {
			if( mes > 0 && mes<= 12) {
				if( mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes == 10 || mes == 12) {
						if (dia > 0 && dia <= 31)
								return true;
				}
				
				else if(mes == 2) {
					if(dia > 0 && dia <= 28)
						return true;
				}
						
				else {
					if(dia > 0 && dia <= 30)
						return true;
				}
			}
		}	
		return false;
	}
	
	/**
	 * Metodo que devuelve la info de la fecha
	 * @return String Devuelve un string que contiene la info de la fecha
	 */
	public String toString() {
		String fecha;
		fecha = anyo + "-" + mes + "-" + dia;
		return fecha;
	}
}
