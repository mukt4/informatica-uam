
package p2.autoescuela;
import p2.autoescuela.clases.Autoescuela;
import p2.autoescuela.clases.Fecha;
import p2.autoescuela.clases.Profesor;
/**
* Tester el primer apartado de la P2
* @author Profesores ADS
*/
public class TesterAutoescuela {
	public static void main(String[] args) {
		Profesor p = new Profesor();
		Autoescuela a = new Autoescuela();
		Fecha f = new Fecha(2,4,2004);
		Fecha f2= new Fecha(4,10,2009);
		a.setNombre("Arenal");
		
		p.setNombre("Antonio");
		p.setApellido("Perez Garcia");
		p.setF_fin(f2);
		p.setF_ini(f);
		
		a.addProfesor(p);
		if(a.getProfesor(p.getId())!=null){
			System.out.print("El profesor " + p.getNombre() +" "+ p.getApellido() + "trabajo en la autoescuela " + a.getNombre() + "desde el " + p.getF_ini() + " hasta el " + p.getF_fin());
		}
	}
}
