package p2.autoescuela.clases;
/**
* Implementacion de la clase de Autoescuela 
*
* @author Tomas Higuera Viso tomas.higuera@estudiante.uam.es y Guillermo Hoyo Bravo guillermo.hoyo@estudiabte.uam.es
*
*/
public class Autoescuela {
	private String nombre;
	private Profesor profesores[];
	
	/**
	 * Constructor del objeto Autoescuela
	 */
	public Autoescuela() {
	}
	
	/**
	 * Metodo getter del nombre
	 * @return String devuelve el nombre
	 */
	public String getNombre() {
		return nombre;
	}
	
	/**
	 * Metodo Setter del nombre
	 * @return
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	/**
	 * Metodo getter del array de profesores
	 * @return profesores devuelve el array de profesores
	 */
	public Profesor[] getProfesores() {
		return profesores;
	}
	
	/**
	 * Metodo Setter del array de profesores
	 * @return
	 */
	public void setProfesores(Profesor profesores[]) {
		this.profesores = profesores;
	}
	
	/**
	 * Metodo que aniade un profesor a su array 
	 * @param p El profesor que sera aniadido al array
	 */
	public void addProfesor(Profesor p) {
		this.profesores[profesores.length] = p;
	}
	
	/**
	 * Metodo que busca un profesor en el array
	 * @param id id del profesor que sera devuelto
	 * @return profesores[i] devuelve un profesor del array con la id pasada como argumento
	 */
	public Profesor getProfesor(int id) {
		for(int i=0; i<profesores.length; i++) {
			if(profesores[i].getId() == id) {
				return profesores[i];
			}
		}
		return null;
	}
	
}
