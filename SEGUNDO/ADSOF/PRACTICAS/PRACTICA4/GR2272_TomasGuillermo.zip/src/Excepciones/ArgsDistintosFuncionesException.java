package Excepciones;

/**
 * Clase public ArgsDistintosFuncionesException que hereda de la clase Exception
 * @author Tomas HIguera Viso y GUillermo Hoyo Bravo
 * @version 1.0
 */
public class ArgsDistintosFuncionesException extends Exception{
    /**
     * Constructor de la excepcion ArgsDistintosFuncionesException
     */
    public ArgsDistintosFuncionesException(){
    }
}
