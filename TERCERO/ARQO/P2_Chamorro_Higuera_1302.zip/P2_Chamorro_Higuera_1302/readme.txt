﻿	readme.txt

	Asignatura: Arquitectura de Computadores (práctica 2)
	Fecha de entrega: 31/10/2018
	Grupo: 1302
	Integrantes: Tomás Higuera Viso y Manuel Chamorro Martínez de Aragón
	Ficheros realizados:
		- processor.vhd (version final incluyendo todos los riesgos de datos, riesgos por carga lw y riesgos por saltos beq)
		- directorio pruebas unitarias:
			- Aqui comprobamos uno a uno todos los riegos que hemos implementado tanto en el ejercicio1, como en el ejercicio2
			- Programa de prueba de adelantamiento de datos para operaciones en la ALU (datos, instrucciones_add y programa_add.asm)
			- Programa de prueba para riesgos de carga de datos en registro lw (datos, instrucciones_lw y programa_lw.asm)
			- Programa de prueba para riesgos de saltos condicionales beq (datos, instrucciones_b y programa_b.asm)
	
	Comentarios:
		Para poder simular con los programas que hemos realizado, es necesario incluir los ficheros datos e instrucciones_x en el directorio de simulación. Además, es necesario
		cambiar el nombre de los ficheros instrucciones_x a "instrucciones" pero hemos decidido dejarlo como está para poder identificar más rápido y evitar confusiones.
		
		Para los riesgos de datos en operaciones aritmético-lógicas, hemos tenido que incorporar una unidad de adelantamiento de datos que tiene en cuenta adelantamientos 
		memoria-ejecución y adelantamientos ejecución-ejecución. Además hemos tenido en cuenta una serie de casos tales como que el registro leido de la operación que causa riesgo
		de lectura de operandos no sea el registro 0, ya que será imposible sobreescribir este registro "especial" y por tanto no existe un riesgo real. Por otro lado hemos tenido
		en cuenta que la instrucción/es anterior/es que causen riesgo y problema deben de tener activa la señal Reg_Write correspondiente ya que si no sobreescriben el valor
		del registro, no tenemos un riesgo real.
		Una cosa a tener en cuenta y que vimos al simular es que se puede producir el caso siguiente:
			ADD $T1, $T2, $T3	
			SUB $T4, $T1, $T1	
		En este caso vemos que tanto op1 como op2 de la instruccion SUB necesitan el valor del registro $T1 que será adelantado. Por tanto no valen sentencias if-elsif si no sentencias
		if-if-if... Por otro lado, debemos de dar prioridad a los adelantamientos ejecución-ejecución frente a los adelantamientos memoria-ejecución. Para ello nos beneficiamos de la 
		particularidad de vhdl en un process, pues asignamos primero los adelantamientos memoria-ejecución y posteriormente los adelantamientos ejecución-ejecución.
		Algo muy parecido hemos realizado para los adelantamientos de salto condicional beq. La condición de salto la realizamos en la segunda etapa (ID), por tanto, además de 
		introducir las "burbujas/nops" pertinentes, debemos adelantar datos a la etapa ID tanto de ejecución como de memoria.

		Por otro lado hemos realizado una unidad de detección de riesgos. La necesitamos tanto para las instrucciones lw como para los saltos condicionales principalmente.
		Sabemos que en una instrucción lw, el valor del registro no se obtiene hasta la etapa MEM, por tanto no podemos aprovechar los adelantamientos ejecución-ejecución. 
		Lo solucionamos introduciendo una burbuja entre una instrucción lw y una instrucción aritmetico-lógica. Hemos implementado esta unidad de la forma más óptima que hemos encontrado.
		Nos hemos dado cuenta que no debemos "parar" el procesador ante cualquier situación. Por ejemplo si nos encontramos con un lw+sw, no paramos el procesador si no que introducimos
		un nuevo adelantamiento mediante un multiplexor que es controlado por la señal Flag_Sw pertinente (esta señal va pasando de pipe en pipe) y adelantamos de la etapa WB a MEM.
		Existen más situaciones donde no debemos de parar el procesador o hacer comprobaciones de datos más precisas como hemos realizado. Por ejemplo si nos encontramos con una secuencia
		de la forma lw+i-type entonces solo debemos de preocuparnos por la lectura de un solo registro.
		Y por último, si tenemos una secuencia de la forma lw+beq con riesgo de datos, entonces debemos introducir una nueva burbuja ya que como hemos mencionado antes, lw obtiene el nnuevo
		valor del registro en la etapa MEM, mientras que la comparación de la condición de salto se realiza en la etapa 2 (ID)  
		
	