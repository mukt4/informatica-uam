	readme.txt

	Asignatura: Arquitectura de Computadores (práctica 1)
	Fecha de entrega: 10/10/2018
	Grupo: 1302
	Integrantes: Tomás Higuera Viso y Manuel Chamorro Martínez de Aragón
	Ficheros realizados:
		- Ejercicio 1:
			- alu_control.vhd
			- control_unit.vhd
			- processor.vhd
		- Ejercicio 2:
			- alu_control.vhd (el mismo del ejercicio 1)
			- control_unit.vhd (el mismo del ejercicio1)
			- processor.vhd (segmentado en 5 etapas)
	
	Comentarios:
		Hemos estado dándole vueltas sobre si adelantar el cálculo de la dirección de salto (procesador segmentado) a la etapa decode (ID) puesto que, al no necesitar de la ALU
		para calcular la dirección de salto en PC, sería más óptima la realización y diseño de esta manera.
		Al contrario que para el branch, ya que la comparación sí que se realiza en la ALU y por tanto necesariamente debe de "durar" mínimo hasta la etapa de execute (EX).
		
	Conclusión:
		Al final nos hemos decantado por calcular la dirección de salto (Jump) en la etapa EX, ya que, aunque funcionaría mejor de la manera que hemos comentado,
		(ahorrándonos un Nop) pero en el caso de que en un programa se plantee lo siguiente, tenemos un riesgo grande de error:
			Beq #, #, target
			Jump target
		En el caso de que nos encontremos esto, tenemos un gran problema ya que si lo hubiesemos diseñado como estamos comentando, la condición de salto no se deshace hasta la 
		instrucción EX, mientras que la dirección de salto incondicional se calcularia en la etapa ID (un ciclo antes). 
		También estuvimos dándole vueltas a una posible solución de este problema y llegamos a la conclusión de que, si se nos plantea esta situación debíamos incluir un Nop entre
		las dos instrucciones y dar prioridad al branch frente al Jump (en caso de que se efectúe el salto en el branch), lo que cambiaría un poco el diseño
		planteado en el enunciado pues tendríamos que invertir el orden de los multiplexores que llegan a PC.
		
		Lo que sí que hemos realizado en efectuar el branch en la etapa EX en lugar de en la etapa MEM, pues nos parecía inútil tener que pasar el flag "Zero" de la ALU por
		la tubería EX/MEM y posteriormente hacer la AND con la señal Branch de la Unidad de control.
		Por tanto y resumiendo, tanto el Branch como el Jump se hacen efectivos en la etapa de ejecución, "colándose" dos intrucciones que en el caso del Jump no se deberían de
		ejecutar en el procesador y tampoco en el caso de que el salto a target por la instrucción Branch se vuelva efectivo.